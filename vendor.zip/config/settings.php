<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 11/3/2016
 * Time: 12:03 PM
 */

include_once(PLUGIN_ROOT_DIR . 'config/manifest.php');
include_once(PLUGIN_ROOT_DIR . 'core/baseCtrl.php');
include_once(PLUGIN_ROOT_DIR . 'core/loader.php');
include_once(PLUGIN_ROOT_DIR . 'config/dbconfig.php');
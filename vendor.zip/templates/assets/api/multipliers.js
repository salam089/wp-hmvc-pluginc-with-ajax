{
  "multipliers" : [{

    "id" : 1,
    "timeFrame": "3",
    "technicalTimeFrame":"3h",
    "quantity":"20",
    "multiplier":5.00

  },
  {

    "id" : 2,
    "timeFrame": "6",
    "technicalTimeFrame":"6h",
    "quantity":"50",
    "multiplier":3.00

  },
  {

    "id" : 3,
    "timeFrame": "12",
    "technicalTimeFrame":"12h",
    "quantity":"100",
    "multiplier":2.00

  },
  {

    "id" : 4,
    "timeFrame": "24",
    "technicalTimeFrame":"24h",
    "quantity":"200",
    "multiplier":1.00

  },
{

    "id" : 5,
    "timeFrame": "48",
    "technicalTimeFrame":"48h",
    "quantity":"1000",
    "multiplier":0.85

  },
  {

    "id" : 6,
    "timeFrame": "24",
    "technicalTimeFrame":"24h",
    "quantity":"5000",
    "multiplier":0.70

  }]

}
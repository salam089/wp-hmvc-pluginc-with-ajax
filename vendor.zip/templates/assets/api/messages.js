{
    "messages"
:
    [{

        "id": 1,

        "name": "quotation1",

        "type": "success",

        "msg": " Your request has been successfully submitted. For your record, an email has been sent to your email address containing your submission details.<p>We�ll look at your request and get back to you soon with any details.</p>",

        "text": "text"

    },
        {

            "id": 2,

            "name": "quotation2",

            "type": "danger",

            "msg": "Oh snap! Change a few things up and try submitting againd.",

            "text": "asdsdsa"

        }]

}

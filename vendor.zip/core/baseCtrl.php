<?php

/**
 * Created by PhpStorm.
 * User: user
 * Date: 11/3/2016
 * Time: 1:28 PM
 */
class baseCls
{


    function __construct(){

    }

}